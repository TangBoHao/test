<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>博客</title>
	<style type="text/css">
		#nav{
			height:108px;
		}
		#nav p{
			font-size: 25px;
		}
		#nav ul{
			float: right;
		}
		#nav li{
			list-style: none;
			float: left;
			margin-right: 10px;

		}
	</style>
</head>
<body>
<div id="nav">
<p>未登陆的博客</p>
<ul>
	<li><a href="landing.html"> 登陆</a></li>
	<li><a href="login.html"> 注册</a></li>
	<li><a href="article.html">查看博文</a></li>
</ul>
	
</div>
<hr/>
<ul id="article">
	
</ul>

</body>
</html>