<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>发表文章结果反馈</title>
</head>
<body>
	<?php

$ti=$_POST['title'];
$con=$_POST['article'];
?>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $_POST['user'];

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检测连接

$sql = "INSERT INTO MyArticle(title, content)
VALUES ('$ti','$con')";

if ($conn->query($sql) === TRUE) {
    echo "发表文章成功";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
</body>
</html>







