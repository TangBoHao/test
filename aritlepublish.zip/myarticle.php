<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>我的文章</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $_POST['name3'];

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检测连接

$sql = "SELECT title,content FROM MyArticle";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        echo "<br>标题: ". $row["title"]. "<br>". $row["content"]."<br>"."<hr>";
    }
} else {
    echo "暂无已发表的内容";
}
$conn->close();
?>
<?php

?>
	
</body>
</html>