<?php 
header("Content-Type:application/json;charset=utf-8");
if($_SERVER["REQUEST_METHOD"] == "POST"){
	save();
}


function save()
{


//$studentid=$_POST['id'];
$name=$_POST['name'];
$major=$_POST['grade'];
$sex=$_POST['sex'];
$phone=$_POST['phone'];
$qq=$_POST['qq'];
$email=$_POST['email'];
$intention=$_POST['intention'];
$experience=$_POST['text_1'];
$advantages=$_POST['text_2'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = 'newbit';
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检测连接
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//设置数据库字符集
mysqli_set_charset ($conn,"utf8");

//防止sql注入

// $studentid= mysql_real_escape_string($studentid)；
// $name= mysql_real_escape_string($name)；
// $phone= mysql_real_escape_string（$phone)；
// $qq= mysql_real_escape_string($qq)；
// $email= mysql_real_escape_string($email)；
// $intention= mysql_real_escape_string($intention)；
// $experience= mysql_real_escape_string($experience)；
// $advantages= mysql_real_escape_string($advantages)；
//插入数据
$sql = "INSERT INTO newstudents (name,major,sex,phone,email,qq,intention,experience,advantage) VALUES ('$name','$major','$sex','$phone','$email','$qq','$intention','$experience','$advantages')";

if ($conn->query($sql) === TRUE) {
    echo "submit success";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

	
	echo "{\"success\":true}";
}
?>