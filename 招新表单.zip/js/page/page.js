window.onload = function(){
	//循环遍历整个表单，加载值
	for (var i = 1; i<9;i++) {
		loadStorage(i,i);
	}
	//控制最后失败的面板是否出现
	$(".weui_btn_dialog").click(function(){
		$(".weui_dialog_alert").css("display","none");
	})


	judge();
	$("#submit").click(function(){
	for (var i = 1; i<9;i++) {
		saveStorage(i,i);
	}



	var url = 're.php';
	var data = {
		name: $("#1").val(),
		grade: $("#2").val(),
		sex: $("#sex").val(),
		phone: $("#3").val(),
		email: $("#4").val(),
		qq: $("#5").val(),
		intention: $("#intention").val(),
		text_1: $("#6").val(),
		text_2: $("#7").val()
	}
	$.ajax({
		type : "POST",
		async : false,
		url : url,
		data : data,
		dataType: "json",
		timeout : 1000,
		success:function(data){
			// alert('123');
			/*console.log("xewx");*/
			console.log(data);
			//clearStorage();
			alert(data.msg);
			//alert("成功");
		},
		error: function(data) {
			console.log(data);
			alert(data.msg);
   		}
	})
})
}
	



function saveStorage(id,i){
	var target = $("#"+id);
	var str = target.val();
	console.log(str);
	localStorage.setItem(i,str);
	console.log(i);
}

function loadStorage(id,i){
	var target = $("#"+id);
	console.log(target);
	var msg = localStorage.getItem(i);
	target.val(msg);
	console.log(msg);
}


function clearStorage(){
	localStorage.clear();
}


function judge(){
	//姓名验证
	var name_test = /[\u4e00-\u9fa5]{2,}/g;
	if(!$("#1").val().match(name_test)){
		if($("#1").val() !== ""){
			$("#1").after('<p style="padding-left: 14px; color: red">姓名输入有误,请输入汉字</p>');
		}
	}
	var stu_number = /^201+[0-9]{9}$/g;
	if (!$("#3").val().match(stu_number)) {
		if($("#3").val() !== ""){
			$("#3").after('<p style="padding-left: 14px; color: red">学号输入有误</p>');
		}
	}
	var phone_number = /^1[3|4|5|7|8]\d{9}$/g;
	if(!$("#4").val().match(phone_number)){
		if($("#4").val() !== ""){
			$("#4").after('<p style="padding-left: 14px; color: red">电话号码输入有误</p>');
		}
	}
	var email = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(!$("#5").val().match(email)){
		if($("#5").val() !== ""){
			$("#5").after('<p style="padding-left: 14px; color: red">邮箱格式输入有误</p>');
		}
	}
	var qq = /^\d{5,11}$/;
	if (!$("#6").val().match(qq)) {
		if($("#6").val() !== ""){
			$("#6").after('<p style="padding-left: 14px; color: red">请输入正确的qq号</p>');
		}
	}
}