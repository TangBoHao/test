<?php 
header("Content-Type: application/json;charset=utf-8");
if($_SERVER["REQUEST_METHOD"] == "POST"){
	save();
}


function save()
{
// 		if (!isset($_POST["name"]) || empty($_POST["name"])
// 		|| !isset($_POST["grade"]) || empty($_POST["grade"])
// 		|| !isset($_POST["phone"]) || empty($_POST["phone"])
// 		|| !isset($_POST["email"]) || empty($_POST["email"])
// 		|| !isset($_POST["qq"]) || empty($_POST["qq"])
// 		|| !isset($_POST["text_1"]) || empty($_POST["text_1"])
// 		|| !isset($_POST["text_2"]) || empty($_POST["text_2"])
// 		) {
// 		echo '{"success":false,"msg":"参数错误，员工信息填写不全"}';
// 		return;
// 	}
// 	else
// 	{
// 		header("Content-type:text/html;charset=utf-8");
// $studentid=$_POST['id'];
// $name=$_POST['name'];
// $major=$_POST['major'];
// $sex=$_POST['sex'];
// $phone=$_POST['phone'];
// $qq=$_POST['qq'];
// $email=$_POST['email'];
// $intention=$_POST['intention'];
// $experience=$_POST['experience'];
// $advantages=$_POST['advantages'];

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = 'newbit';
// // 创建连接
// $conn = new mysqli($servername, $username, $password, $dbname);
// // 检测连接
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// } 

// //设置数据库字符集
// mysqli_set_charset ($conn,"utf8");

// //防止sql注入
// // $studentid= mysql_real_escape_string($studentid)；
// // $name= mysql_real_escape_string($name)；
// // $phone= mysql_real_escape_string（$phone)；
// // $qq= mysql_real_escape_string($qq)；
// // $email= mysql_real_escape_string($email)；
// // $intention= mysql_real_escape_string($intention)；
// // $experience= mysql_real_escape_string($experience)；
// // $advantages= mysql_real_escape_string($advantages)；
// //插入数据
// $sql = "INSERT INTO newstudents (studentid,name,major,sex,phone,email,qq,intention,experience,advantage) VALUES ('$studentid','$name','$major','$sex','$phone','$email','$qq','$intention','$experience','$advantages')";

// if ($conn->query($sql) === TRUE) {
//     echo "submit success";
// } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
// }

// $conn->close();


// 	}
	echo '{"success":success}';
}
?>